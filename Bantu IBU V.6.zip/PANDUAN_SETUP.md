# 📋 Panduan Setup BantuIbu — Arsitektur Data Terpisah

## Struktur File yang Sudah Dibuat

```
📁 bantuibu/
├── 📄 BantuIbu_KIA_main.html    ← File HTML utama (taruh di mana saja)
├── 📁 data/
│   ├── 📄 zscore.json           ← Data Z-Score BB/TB
│   ├── 📄 edukasi.json          ← Data edukasi, perkembangan, pola asuh
│   ├── 📄 imunisasi.json        ← Jadwal imunisasi
│   └── 📄 pkg.json              ← Data PKG Posyandu
└── 📄 PANDUAN_SETUP.md          ← File ini
```

---

## 🚀 LANGKAH SETUP (GitHub + jsDelivr)

### LANGKAH 1 — Buat Akun GitHub (Gratis)
1. Buka https://github.com
2. Klik **Sign up** → isi nama, email, password
3. Verifikasi email Anda

---

### LANGKAH 2 — Buat Repository Baru
1. Setelah login, klik tombol **+** di pojok kanan atas
2. Pilih **New repository**
3. Isi:
   - **Repository name**: `bantuibu-data` (atau nama lain bebas)
   - **Description**: Data website BantuIbu
   - Pilih **Public** ✅ (wajib agar jsDelivr bisa akses)
4. Klik **Create repository**

---

### LANGKAH 3 — Upload File JSON
1. Di halaman repository, klik **Add file** → **Upload files**
2. Buat folder `data/` dengan cara:
   - Klik **creating a new file**
   - Ketik nama file: `data/zscore.json`
   - Copy-paste isi file `zscore.json` ke editor
   - Klik **Commit new file**
3. Ulangi untuk `edukasi.json`, `imunisasi.json`, `pkg.json`

> **Tips cepat:** Anda bisa drag & drop semua file JSON sekaligus ke halaman upload

---

### LANGKAH 4 — Dapatkan URL jsDelivr
Setelah upload, URL data Anda akan berbentuk:
```
https://cdn.jsdelivr.net/gh/USERNAME/NAMA-REPO@main/data/zscore.json
```

Contoh jika username GitHub Anda `drreza` dan repo `bantuibu-data`:
```
https://cdn.jsdelivr.net/gh/drreza/bantuibu-data@main/data/zscore.json
```

---

### LANGKAH 5 — Edit HTML Utama
Buka file `BantuIbu_KIA_main.html`, cari bagian ini di bagian atas script:

```javascript
// ══════════════════════════════════════════════════════════════
// KONFIGURASI URL DATA — Ganti dengan URL hosting Anda
// ══════════════════════════════════════════════════════════════
const DATA_BASE_URL = 'https://cdn.jsdelivr.net/gh/USERNAME/REPO-NAME@main/data';
```

Ganti `USERNAME` dengan username GitHub Anda, dan `REPO-NAME` dengan nama repository.

**Contoh:**
```javascript
const DATA_BASE_URL = 'https://cdn.jsdelivr.net/gh/drreza/bantuibu-data@main/data';
```

---

### LANGKAH 6 — Test
Buka file `BantuIbu_KIA_main.html` di browser.
Website akan otomatis fetch data dari GitHub.

---

## ✏️ CARA UPDATE DATA

Ketika ada data yang perlu diubah (misal: tambah imunisasi baru):

1. Buka GitHub → masuk ke repository Anda
2. Klik file JSON yang ingin diedit (misal: `data/imunisasi.json`)
3. Klik ikon pensil ✏️ (Edit this file)
4. Ubah data yang diperlukan
5. Klik **Commit changes**

✅ **Selesai!** Perubahan berlaku otomatis dalam 5–10 menit
(jsDelivr cache otomatis refresh)

---

## ⚡ Cache Refresh Manual

Jika perubahan belum muncul, buka URL ini di browser:
```
https://purge.jsdelivr.net/gh/USERNAME/REPO-NAME@main/data/imunisasi.json
```
Ini akan memaksa jsDelivr mengambil data terbaru dari GitHub.

---

## 🔒 Keamanan

- File JSON di GitHub bersifat **public** (bisa dilihat)
- Tapi kode logika tetap ada di HTML → tidak mudah dicopy secara keseluruhan
- Jika ingin data private, Anda perlu backend (PHP/Node.js) dengan autentikasi

---

## ❓ FAQ

**Q: Apakah gratis?**
A: Ya, GitHub dan jsDelivr 100% gratis untuk ukuran file seperti ini.

**Q: Kalau internet mati, website tidak bisa dipakai?**
A: Benar, karena data di-fetch dari internet. Solusinya bisa tambah Service Worker untuk cache offline.

**Q: Bisa ganti GitHub dengan hosting sendiri?**
A: Bisa! Cukup upload 4 file JSON ke hosting Anda, lalu ganti URL di `DATA_BASE_URL`.
Pastikan hosting mengaktifkan CORS (biasanya sudah aktif di hosting modern).

---

*Dibuat untuk UPT Puskesmas Sipayung | Sumber: Buku KIA 2024 Kemenkes RI*
